import argparse
import datetime
from pathlib import Path
from typing import Any, Dict, List, Tuple

import yaml


# keys we care most about in 5G/srsRAN agile setups
DEFAULT_TRACKED_KEYS = [
    "gnb.plmn_id",
    "gnb.tac",
    "gnb.nr_band",
    "ru_sdr.tx_gain",
    "ru_sdr.rx_gain",
    "amf.addr",
    "core.plmn_id",
    "interfaces.n2",
    "interfaces.n3",
]


def load_yaml(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def _flatten(d: Dict[str, Any], parent: str = "") -> Dict[str, Any]:
    """Flatten nested dict into dot.notation: value."""
    items: Dict[str, Any] = {}
    for k, v in d.items():
        new_key = f"{parent}.{k}" if parent else k
        if isinstance(v, dict):
            items.update(_flatten(v, new_key))
        else:
            items[new_key] = v
    return items


def diff_dicts(
    old: Dict[str, Any], new: Dict[str, Any], tracked: List[str]
) -> List[Tuple[str, Any, Any]]:
    """Return list of (key, old_val, new_val) for changed keys."""
    flat_old = _flatten(old)
    flat_new = _flatten(new)
    changes: List[Tuple[str, Any, Any]] = []

    # if tracked empty → track everything
    keys_to_check = tracked or sorted(set(flat_old) | set(flat_new))

    for key in keys_to_check:
        o = flat_old.get(key, "<missing>")
        n = flat_new.get(key, "<missing>")
        if o != n:
            changes.append((key, o, n))
    return changes


def append_changelog(
    out_file: Path,
    changes: List[Tuple[str, Any, Any]],
    old_path: Path,
    new_path: Path,
    sprint: str = "",
) -> None:
    out_file.parent.mkdir(parents=True, exist_ok=True)
    ts = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
    title = f"## {ts}"
    if sprint:
        title += f" – {sprint}"

    lines = [title, f"- from: `{old_path}`", f"- to:   `{new_path}`"]

    if not changes:
        lines.append("- no tracked changes detected ✅")
    else:
        lines.append("- changes:")
        for key, old_val, new_val in changes:
            lines.append(f"  - `{key}`: `{old_val}` → `{new_val}`")

    with out_file.open("a", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n\n")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Compare two YAML configs and append changes to changelog."
    )
    parser.add_argument("--old", required=True, help="old YAML file")
    parser.add_argument("--new", required=True, help="new YAML file")
    parser.add_argument("--out", required=True, help="output markdown changelog")
    parser.add_argument(
        "--sprint", default="", help="optional sprint/iteration name to record"
    )
    parser.add_argument(
        "--all", action="store_true", help="track ALL keys, not only 5G-related ones"
    )
    args = parser.parse_args()

    old_cfg = load_yaml(Path(args.old))
    new_cfg = load_yaml(Path(args.new))

    tracked = [] if args.all else DEFAULT_TRACKED_KEYS
    changes = diff_dicts(old_cfg, new_cfg, tracked)

    append_changelog(
        Path(args.out),
        changes,
        Path(args.old),
        Path(args.new),
        sprint=args.sprint,
    )

    if changes:
        print(f"{len(changes)} change(s) recorded to {args.out}")
    else:
        print("No changes detected for tracked keys.")


if __name__ == "__main__":
    main()
