from src.docsync import diff_dicts

def test_diff_dicts_empty_tracked():
    old = {"a": 1}
    new = {"a": 2}
    changes = diff_dicts(old, new, [])
    assert len(changes) == 1
